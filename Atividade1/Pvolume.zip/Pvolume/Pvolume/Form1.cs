﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pvolume
{
    public partial class Form1 : Form
    {
        double raio, altura, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtaltura_Validating(object sender, CancelEventArgs e)
        {
            if(!Double.TryParse(txtaltura.Text, out altura))
            {
                MessageBox.Show("Altura inválida!");
                e.Cancel = true;
            }
            else if(altura <= 0){
                MessageBox.Show("Altura deve ser maior que 0!");
                e.Cancel = true;
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            resultado = Math.PI * Math.Pow(raio, 2) * altura;
            txtresultado.Text = resultado.ToString("N2");
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtraio.Text = "";
            txtaltura.Text = string.Empty;
            txtresultado.Clear();
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtraio_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtraio_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtraio.Text, out raio))
            {
                MessageBox.Show("Raio inválido!");
                txtraio.Focus();
            }
            else
            {
                if (raio <= 0)
                {
                    MessageBox.Show("Raio deve ser maior do que 0!");
                    txtraio.Focus();
                }
            }
        }
    }
}
