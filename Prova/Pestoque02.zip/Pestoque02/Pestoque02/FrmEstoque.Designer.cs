﻿namespace Pestoque02
{
    partial class FrmEstoque
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            btnVerificar = new Button();
            btnLimpar = new Button();
            listBox1 = new ListBox();
            errorProvider1 = new ErrorProvider(components);
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            SuspendLayout();
            // 
            // btnVerificar
            // 
            btnVerificar.BackColor = SystemColors.InactiveBorder;
            btnVerificar.Location = new Point(121, 124);
            btnVerificar.Name = "btnVerificar";
            btnVerificar.Size = new Size(228, 103);
            btnVerificar.TabIndex = 0;
            btnVerificar.Text = "Verificar";
            btnVerificar.UseVisualStyleBackColor = false;
            btnVerificar.Click += BtnVerificar_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.BackColor = SystemColors.ButtonHighlight;
            btnLimpar.Location = new Point(121, 327);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(228, 103);
            btnLimpar.TabIndex = 1;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = false;
            btnLimpar.Click += BtnLimpar_Click;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 25;
            listBox1.Location = new Point(466, 43);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(538, 479);
            listBox1.TabIndex = 2;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // FrmEstoque
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1063, 569);
            Controls.Add(listBox1);
            Controls.Add(btnLimpar);
            Controls.Add(btnVerificar);
            Name = "FrmEstoque";
            Text = "Estoque";
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button btnVerificar;
        private Button btnLimpar;
        private ListBox listBox1;
        private ErrorProvider errorProvider1;
    }
}
