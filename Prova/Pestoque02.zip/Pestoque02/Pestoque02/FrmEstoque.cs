using Microsoft.VisualBasic;

namespace Pestoque02
{
    public partial class FrmEstoque : Form
    {
        public FrmEstoque()
        {
            InitializeComponent();
        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            int[,] produtos = new int[4, 4];

            string aux;

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    
                    while (true)
                    {
                        aux = Interaction.InputBox($"Digite o total de entrada do Produto {i + 1} na Semana {j + 1}: ", "Entrada de respostas");

                        if (!int.TryParse(aux, out produtos[i, j]))
                        {
                            errorProvider1.SetError(listBox1, "O valor inserido n�o � v�lido");
                        }
                        else if (produtos[i, j] < 0)
                        {
                            errorProvider1.SetError(listBox1, "O n�mero inserido deve ser maior ou igual a 0");
                        }
                        else
                        {
                            errorProvider1.Clear();
                            break;
                        }
                    }
                }
            }

            int total_geral = 0;

            for (int i = 0; i < 4; i++)
            {
                int total_prod = 0;

                for (int j = 0; j < 4; j++)
                {
                    aux = $"Total de entradas do Produto: {i + 1} Semana: {j + 1} - {produtos[i, j]}";
                    total_prod += produtos[i, j];

                    listBox1.Items.Add(aux);
                }
                total_geral += total_prod;

                listBox1.Items.Add($">> Total Entradas do Produto {i + 1}:\t       {total_prod}");
                listBox1.Items.Add($"---------------------------------------------------------");
            }

            listBox1.Items.Add($">> Total Geral Entradas:\t\t      {total_geral}");

        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }
    }
}
