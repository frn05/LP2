﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade7
{
    public partial class Exercicio2 : Form
    {
        public Exercicio2()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int num = Convert.ToInt32(txtNumero.Text);
            double h = 0;
            for(double i = 1; i < num; i++)
            {
                 h = h + 1 / i;
            }
            MessageBox.Show($"Resultado: {Math.Round(h, 2)}");
        }

        private void txtNumero_Validated(object sender, EventArgs e)
        {
            int num;
            if(!int.TryParse(txtNumero.Text, out num) || num < 0)
            {
                MessageBox.Show("numero invalido");
                txtNumero.Focus();
            }
        }
    }
}
