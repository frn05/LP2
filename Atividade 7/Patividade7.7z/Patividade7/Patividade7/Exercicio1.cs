﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade7
{
    public partial class Exercicio1 : Form
    {
        int tamanho;
        string texto;
        public Exercicio1()
        {
            InitializeComponent();
        }

        private void btnEspaçoBranco_Click(object sender, EventArgs e)
        {
            int i = 0;
            texto = richtxtFrase.Text;
            tamanho = richtxtFrase.Text.Length;
            foreach(char c in texto)
            {
                if(c ==  ' ')
                {
                    i++;
                }
            }
            MessageBox.Show($"Numero de espaços em branco: {i}");
        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            int i = 0, qntd = 0;
            tamanho = richtxtFrase.Text.Length;
            for(i=0; i<tamanho; i++)
            {
                if (Char.ToLower(richtxtFrase.Text[i]) == 'r') 
                {
                    qntd++;
                }
            }
            MessageBox.Show($"Numero de R na frase: {qntd}");
        }

        private void btnRepetidas_Click(object sender, EventArgs e)
        {
            int i = 0, qntd = 0;
            int tamanho = richtxtFrase.Text.Length;
            while(i < tamanho-1)
            {
                if (richtxtFrase.Text[i] == richtxtFrase.Text[i + 1])
                {
                    qntd++;
                }
                i++;
            }
            MessageBox.Show($"Quantidade de letras repetidas: {qntd}");
        }
    }
}
