﻿namespace Patividade7
{
    partial class Exercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnEspaçoBranco = new System.Windows.Forms.Button();
            this.btnLetraR = new System.Windows.Forms.Button();
            this.btnRepetidas = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richtxtFrase
            // 
            this.richtxtFrase.Location = new System.Drawing.Point(174, 46);
            this.richtxtFrase.Name = "richtxtFrase";
            this.richtxtFrase.Size = new System.Drawing.Size(352, 209);
            this.richtxtFrase.TabIndex = 0;
            this.richtxtFrase.Text = "";
            // 
            // btnEspaçoBranco
            // 
            this.btnEspaçoBranco.Location = new System.Drawing.Point(145, 298);
            this.btnEspaçoBranco.Name = "btnEspaçoBranco";
            this.btnEspaçoBranco.Size = new System.Drawing.Size(100, 72);
            this.btnEspaçoBranco.TabIndex = 1;
            this.btnEspaçoBranco.Text = "Numero de espaço em branco";
            this.btnEspaçoBranco.UseVisualStyleBackColor = true;
            this.btnEspaçoBranco.Click += new System.EventHandler(this.btnEspaçoBranco_Click);
            // 
            // btnLetraR
            // 
            this.btnLetraR.Location = new System.Drawing.Point(301, 297);
            this.btnLetraR.Name = "btnLetraR";
            this.btnLetraR.Size = new System.Drawing.Size(100, 73);
            this.btnLetraR.TabIndex = 2;
            this.btnLetraR.Text = "Numero de R na frase";
            this.btnLetraR.UseVisualStyleBackColor = true;
            this.btnLetraR.Click += new System.EventHandler(this.btnLetraR_Click);
            // 
            // btnRepetidas
            // 
            this.btnRepetidas.Location = new System.Drawing.Point(454, 296);
            this.btnRepetidas.Name = "btnRepetidas";
            this.btnRepetidas.Size = new System.Drawing.Size(100, 74);
            this.btnRepetidas.TabIndex = 3;
            this.btnRepetidas.Text = "Numero de letras seguidas";
            this.btnRepetidas.UseVisualStyleBackColor = true;
            this.btnRepetidas.Click += new System.EventHandler(this.btnRepetidas_Click);
            // 
            // Exercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnRepetidas);
            this.Controls.Add(this.btnLetraR);
            this.Controls.Add(this.btnEspaçoBranco);
            this.Controls.Add(this.richtxtFrase);
            this.Name = "Exercicio1";
            this.Text = "Exercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox richtxtFrase;
        private System.Windows.Forms.Button btnEspaçoBranco;
        private System.Windows.Forms.Button btnLetraR;
        private System.Windows.Forms.Button btnRepetidas;
    }
}