﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade7
{
    public partial class Exercicio4 : Form
    {
        public Exercicio4()
        {
            InitializeComponent();
        }

        private void btnSalarioBruto_Click(object sender, EventArgs e)
        {
            double salbruto;
            double a = Convert.ToDouble(txtSalario.Text);
            double grat = Convert.ToDouble(txtGratificacao.Text);
            int prod = Convert.ToInt32(txtProdução.Text);
            int b = 0, c = 0, d = 0;
            if(prod >= 150)
            {
                b = 1;
                c = 1;
                d = 1;
            }else if(prod >= 120)
            {
                b = 1;
                c = 1;
            }else if (prod >= 100)
            {
                b = 1;
            }
            salbruto = a + a*(0.05*b+0.1*c+0.1*d) + grat;
            if(salbruto > 7000 && prod < 150)
            {
                salbruto = 7000;
            }
            MessageBox.Show($"O salario é: {salbruto}");

        }   

        private void txtProdução_Validated(object sender, EventArgs e)
        {
            int producao;
            if (!int.TryParse(txtProdução.Text, out producao) || producao < 0)
            {
                MessageBox.Show("Producao invalida");
                txtProdução.Focus();
            }
        }

        private void txtSalario_Validated(object sender, EventArgs e)
        {
            double salario;
            if(!Double.TryParse(txtSalario.Text, out salario) || salario < 0)
            {
                MessageBox.Show("Salario invalido");
                txtSalario.Focus();
            }
        }

        private void txtGratificacao_Validated(object sender, EventArgs e)
        {
            double gratificacao;
            if (!Double.TryParse(txtGratificacao.Text, out gratificacao) || gratificacao < 0)
            {
                MessageBox.Show("Gratificação invalida");
                txtGratificacao.Focus();
            }
        }
    }
}
