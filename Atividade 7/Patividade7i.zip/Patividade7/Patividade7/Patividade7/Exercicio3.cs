﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade7
{
    public partial class Exercicio3 : Form
    {
        public Exercicio3()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnPalindromo_Click(object sender, EventArgs e)
        {
            string frase = textBox1.Text.ToLower().Replace(" ", "");
            string contrario = new string(frase.Reverse().ToArray());
            if (textBox1.Text.Length > 50)
            {
                MessageBox.Show("Frase muito grande, coloque outra");
            }
            else
            {
                if (contrario == frase)
                {
                    MessageBox.Show("É um palíndromo!");
                }
                else
                {
                    MessageBox.Show("Não é um palíndromo");
                }
            }

        }
    }
}
