﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void forms1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Exercicio1>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                // da erro se forms nao tem nada
                Application.OpenForms["Exercicio1"].BringToFront();
                //ou
                //Application.OpenForms["frmExercicio3"].Activate();
            }
            else
            {
                Exercicio1 obj2 = new Exercicio1();
                obj2.MdiParent = this;//form1
                obj2.WindowState = FormWindowState.Maximized;
                obj2.Show();
            }
        }

        private void forms2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Exercicio2>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                // da erro se forms nao tem nada
                Application.OpenForms["Exercicio2"].BringToFront();
                //ou
                //Application.OpenForms["frmExercicio3"].Activate();
            }
            else
            {
                Exercicio2 obj3 = new Exercicio2();
                obj3.MdiParent = this;//form1
                obj3.WindowState = FormWindowState.Maximized;
                obj3.Show();
            }
        }

        private void forms3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Exercicio3>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                // da erro se forms nao tem nada
                Application.OpenForms["Exercicio3"].BringToFront();
                //ou
                //Application.OpenForms["frmExercicio3"].Activate();
            }
            else
            {
                Exercicio3 obj4 = new Exercicio3();
                obj4.MdiParent = this;//form1
                obj4.WindowState = FormWindowState.Maximized;
                obj4.Show();
            }
        }

        private void forms4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Exercicio4>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                // da erro se forms nao tem nada
                Application.OpenForms["Exercicio4"].BringToFront();
                //ou
                //Application.OpenForms["frmExercicio3"].Activate();
            }
            else
            {
                Exercicio4 obj5 = new Exercicio4();
                obj5.MdiParent = this;//form1
                obj5.WindowState = FormWindowState.Maximized;
                obj5.Show();
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
