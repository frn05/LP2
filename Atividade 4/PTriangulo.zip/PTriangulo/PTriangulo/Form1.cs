﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double a, b, c;

        private void txtValorB_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtValorB.Text, out b) ||b <= 0)
            {
                MessageBox.Show("Numero invalido!");
                txtValorB.Focus();
            }
        }

        private void txtValorC_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtValorC.Text, out c) || c <= 0)
            {
                MessageBox.Show("Numero invalido!");
                txtValorC.Focus();
            }
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if((a < b + c) && (a > Math.Abs(b - c)) && (b < a + c) && (b > Math.Abs(a - c)) 
                && (c < a + b) && (b > Math.Abs(a - b)))
            {
                if((a == b && c != b) || (b == c && a != c) || (c == a && b != a))
                {
                    MessageBox.Show("Triangulo Isoceles");
                }
                else if(a == b && a == c) 
                {
                    MessageBox.Show("Triangulo Equilatero");
                }
                else
                {
                    MessageBox.Show("Triangulo Escaleno");
                }
            }
            else
            {
                MessageBox.Show("Valores não são válidos para um triangulo");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValorA.Text = string.Empty;
            txtValorB.Text = string.Empty;
            txtValorC.Text = string.Empty;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtValorA_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(txtValorA.Text, out a) || a <= 0)
            {
                MessageBox.Show("Numero invalido!");
                txtValorA.Focus();
            }
        }
    }
}
