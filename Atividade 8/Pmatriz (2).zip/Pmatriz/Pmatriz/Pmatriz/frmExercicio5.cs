﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatriz
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            char ajuda;
            string auxiliar = "";
            int qntd,i;
            string auxiliar2 = "";
            auxiliar = Interaction.InputBox("Digite o RA:", "Entrada de Dados");
            char[] array = auxiliar.ToCharArray();
            int tamanho = array.Length;
            string[] gabarito = { "A", "B", "B", "C", "D", "D", "A", "C", "A", "D" };
            qntd = (int)char.GetNumericValue(array[tamanho - 1]);
            if (qntd == 0)
            {
                qntd = 2;
            }
            else if(qntd == 9)
            {
                qntd = 1;
            }
            else
            {
                qntd += 1;
            }
            for(i = 0; i < qntd; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    auxiliar2 = Interaction.InputBox($"Digite a resposta da questao {j+1}", "Respostas");
                    if(auxiliar2 == gabarito[j])
                    {
                        listBox1.Items.Add($"O aluno {i + 1} acertou questão {j + 1}, era {gabarito[j]} e escolheu {auxiliar2}");
                    }
                    else
                    {
                        listBox1.Items.Add($"O aluno {i + 1} errou questão {j + 1}, era {gabarito[j]} e escolheu {auxiliar2}");
                    }
                }
            }
            
            
        }
    }
}
