﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatriz
{
    public partial class FrmExercicio4 : Form
    {
        public FrmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string auxiliar = "";
            int cont = 0;
            for (int i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox("Digite um nome:", "Entrada de Dados");
                foreach(char c in auxiliar)
                {
                    if(c != ' ')
                    {
                        cont++;
                    }
                }
                listBox1.Items.Add($"nome: {auxiliar} tem {cont} caracteres");
                cont = 0;
            }
        }
    }
}
