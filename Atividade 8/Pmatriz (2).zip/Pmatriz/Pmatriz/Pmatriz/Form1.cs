﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatriz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            for(int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i+1}° numero", "Entrada de Dados");

                if (auxiliar == "")
                    break;

                if(!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Numero invalido");
                    i--;
                }
            }
            Array.Reverse(vetor);
            auxiliar = "";
            foreach(int i in vetor)
            {
                auxiliar += i + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList nomes = new ArrayList();
            nomes.Add("Ana");
            nomes.Add("Andre");
            nomes.Add("Debora");
            nomes.Add("Fatima");
            nomes.Add("João");
            nomes.Add("Janete");
            nomes.Add("Otavio");
            nomes.Add("Marcelo");
            nomes.Add("Pedro");
            nomes.Add("Thais");

            nomes.Remove("Otavio");
            
            foreach(string name in nomes)
            {
                MessageBox.Show(name);
            }
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string auxiliar = "";
            double[] media = new double[20];
            for (int i = 0;i < 20; i++)
            {
                for(int j = 0;j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a {j+1}° nota do {i+1}° aluno");
                    if(!Double.TryParse(auxiliar, out notas[i,j]) || notas[i,j] < 0 || notas[i,j] > 10)
                    {
                        MessageBox.Show("Nota invalida");
                        j--;
                    }
                    else
                    {
                        media[i] = media[i] + notas[i,j];
                    }
                    
                }
                media[i] = media[i] / 3.0;
            }
            int cont = 1;
            foreach(double i in media)
            {
                MessageBox.Show($"Aluno {cont} media: {i}");
                cont++;
            }
        }

        private void btnExercico4_Click(object sender, EventArgs e)
        {
            if(Application.OpenForms.OfType<FrmExercicio4>().Count() > 0)
            {
                MessageBox.Show("Forms ja aberto");
                Application.OpenForms["frmExercicio4"].BringToFront();
            }
            else
            {
                FrmExercicio4 obj1 = new FrmExercicio4();
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {
                MessageBox.Show("Forms ja aberto");
                Application.OpenForms["frmExercicio5"].BringToFront();
            }
            else
            {
                frmExercicio5 obj2 = new frmExercicio5();
                obj2.WindowState = FormWindowState.Maximized;
                obj2.Show();
            }
        }
    }
}
