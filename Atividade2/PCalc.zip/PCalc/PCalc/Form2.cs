﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalc
{
    public partial class Form2 : Form
    {
        double numero1, numero2, resultado;
        public Form2()
        {
            InitializeComponent();
        }

        private void textNumero1_Validated_1(object sender, EventArgs e)
        {
            if(!Double.TryParse(textNumero1.Text, out numero1))
            {
                errorProvider1.SetError(textNumero1, "Numero inválido!");
            }
            else
            {
                errorProvider1.SetError(textNumero1, "");
            }
        }

        private void textNumero2_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(textNumero2.Text, out numero2))
            {
                errorProvider2.SetError(textNumero2, "Numero inválido!");
            }
            else
            {
                errorProvider2.SetError(textNumero2, "");
            }
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(textNumero1.Text, out numero1) || !Double.TryParse(textNumero2.Text, out numero2))
            {
                textNumero1.Focus();
            }
            else
            {
                resultado = numero1 + numero2;
                textResultado.Text = resultado.ToString();
            }
        }

        private void btnSubtração_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(textNumero1.Text, out numero1) || !Double.TryParse(textNumero2.Text, out numero2))
            {
                textNumero1.Focus();
            }
            else
            {
                resultado = numero1 - numero2;
                textResultado.Text = resultado.ToString();
            }
        }

        private void btnDivisão_Click(object sender, EventArgs e)
        {
            if(!Double.TryParse(textNumero1.Text, out numero1) || !Double.TryParse(textNumero2.Text, out numero2))
            {
                textNumero1.Focus();
            }
            else
            {
                if(numero2 == 0)
                {
                    errorProvider2.SetError(textNumero2, "Numero inválido!");
                }
                else
                {
                    resultado = numero1 / numero2;
                    textResultado.Text= resultado.ToString();
                }
            }
        }

        private void btnMultiplicação_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(textNumero1.Text, out numero1) || !Double.TryParse(textNumero2.Text, out numero2))
            {
                textNumero1.Focus();
            }
            else
            {
                resultado = numero1 * numero2;
                textResultado.Text = resultado.ToString();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            textNumero1.Text = String.Empty;
            textNumero2.Text = String.Empty;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textNumero1_Validated(object sender, EventArgs e)
        {
            
        }
    }
}
